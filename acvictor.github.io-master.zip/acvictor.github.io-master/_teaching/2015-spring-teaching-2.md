---
title: "Teaching Assistant"
collection: teaching
type: "CS606: Computer Graphics"
permalink: /teaching/
venue: 
date: 2019-01-01
location: "City, Country"
---

Teaching assistant for the graduate level computer graphics course at the International Institute of Information Technology Bangalore.

Heading 1
======

Heading 2
======

Heading 3
======
