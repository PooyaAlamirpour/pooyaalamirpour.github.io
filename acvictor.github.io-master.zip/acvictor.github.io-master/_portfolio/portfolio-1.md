---
title: "TEDxIIITBangalore"
excerpt: "Selected designs from my work for TEDxIIITBangalore <br/><br/><img src='/images/TEDxCover.png'>"
collection: portfolio
---
